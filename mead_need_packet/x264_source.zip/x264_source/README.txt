编译x264方法：
环境：mingw + msys
1、./configure --disable-cli --enable-shared --extra-ldflags=-Wl,--output-def=libx264.def
2、LIB /DEF:libx264.def 
生成lib和dll